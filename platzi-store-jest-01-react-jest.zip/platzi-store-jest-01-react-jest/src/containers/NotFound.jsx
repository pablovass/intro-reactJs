import React from 'react';

const NotFound = () => (
  <h1>NotFound</h1>
);

export default NotFound;
